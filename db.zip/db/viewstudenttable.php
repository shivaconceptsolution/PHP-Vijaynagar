<?php
include('header.php');

if(!isset($_SESSION['uid']))
{
    echo "<script>window.location='index.php';</script>";
}
include_once('conn.php');
?>
<div id="section">
<br>

<table border='1'>
   <tr><th colspan="6">All Student Record</th></tr>
    <tr><th>rno</th><th>name</th><th>branch</th><th>fees</th><th colspan="2">Edit/Delete</th></tr>
<?php


$query = mysqli_query($conn,"select * from student");
while($res = mysqli_fetch_array($query))
{ ?>
  <tr><td><?php echo $res[0]; ?></td><td><?php echo $res[1]; ?></td><td><?php echo $res[2]; ?></td><td><?php echo $res[3]; ?></td>
  <td><a href="editstudent.php?q=<?php echo $res[0]; ?>">Edit</a></td><td><a href="deletestudent.php?q=<?php echo $res[0]; ?>">Delete</a></td></tr>
</tr>
<?php }




?>
</table>
</div>
<?php
include('footer.php');
?>