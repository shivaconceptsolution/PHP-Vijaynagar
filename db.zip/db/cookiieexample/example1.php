<?php

setcookie('cuid','aman',time()+3600);
?>

<a href="example2.php">cookiepage2 </a>