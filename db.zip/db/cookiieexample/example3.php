<?php

setcookie('cuid','',time()-3600);  //remove cookie

?>

<a href="example2.php">cookiepage2 </a>