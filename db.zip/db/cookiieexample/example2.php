<?php

echo $_COOKIE['cuid'];

?>
<a href="example3.php">Cookie Page 3</a>