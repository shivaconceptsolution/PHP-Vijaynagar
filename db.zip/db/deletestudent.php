<!DOCTYPE html>
<html lang="en">
<?php
include('header.php');
?>
<div id="section">
    <br><br>


    <h1>Are you sure to delete the record of student whose rno is <?php echo $_GET['q']; ?></h1>
    
    <?php
    $rno= $_GET['q'];
    $conn = mysqli_connect('localhost','root','','schooldb');   
    $query = mysqli_query($conn,"select * from student where rno=$rno");
    $data = mysqli_fetch_row($query);
    ?>
    <form action="" method="post">
        <table>
            <tr>
     <td> RNO:  </td><td> <?php echo $data[0]; ?></td></tr>
     <tr>
     <td>Name  </td><td> <?php echo $data[1]; ?> </td></tr>
     <tr>
     <td> Branch </td><td><?php echo $data[2]; ?></td></tr>
     <tr>
     <td>Fees   </td><td><?php echo $data[3]; ?></td></tr>
     <tr>
     <td colspan="2" align='left'> <input type="submit" name="btnsubmit" value="Delete" /></td></tr>
</table>
    </form>

    <?php
    if(isset($_POST['btnsubmit']))
    {
        $rno = $_POST['txtrno'];
     
        $query=mysqli_query($conn,"delete from student where rno=$rno");
        if(mysqli_affected_rows($conn)>0)
        {
            echo "<script>window.location='viewstudenttable.php';</script>";
        }

    }
    ?>
</div>
<?php
include('footer.php');
?>