<!DOCTYPE html>
<html lang="en">
<?php
include('header.php');
?>
<div id="section">
    <br><br>

    <form action="" method="post" style="padding-left:50px;">
       <h3>Add Student Record From Here</h3>
        <input type="text" placeholder="Enter rno" name="txtrno" /> <br>
        <input type="text" placeholder="Enter name" name="txtname"  /> <br>
        <input type="text" placeholder="Enter branch" name="txtbranch"  /> <br>
        <input type="text" placeholder="Enter fees" name="txtfees"  /> <br>
        <input type="submit" name="btnsubmit" value="Insert"  />

    </form>
    
    <?php
     include_once('conn.php');
          if(isset($_POST['btnsubmit']))
          {
               $rno= $_POST['txtrno'];
               $name = $_POST['txtname'];
               $branch=$_POST['txtbranch'];
               $fees = $_POST['txtfees'];
             
               $query  = mysqli_query($conn,"insert into student(rno,sname,branch,fees) values($rno,'$name','$branch',$fees)");   
               if(mysqli_affected_rows($conn)>0)
               {
                      echo "Data Inserted Successfully";
               }
               else
               {
                   echo "Problem in data insertion";
               }



          }




    ?>
    </div>
<?php
include('footer.php');
?>