<?php
  $conn = mysqli_connect('localhost','root','','schooldb');   
   if(!$conn)
   {
     mysqli_error($conn);
   }
 ?>